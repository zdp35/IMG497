extends CharacterBody2D
class_name Player

signal died(killer_id: int, victim_id: int)

enum CharacterType { DEFAULT, TESLA, JOAN }

var character_type: CharacterType = CharacterType.DEFAULT

func set_character_type(new_type: CharacterType) -> void:
    character_type = new_type
    _update_visuals_from_character_type()
    _update_local_ui()

const TEX_JOAN_IDLE  := preload("res://art/joan_idle.png")
const TEX_TESLA_IDLE := preload("res://art/tesla_idle.png")

@onready var sprite: Sprite2D = $Sprite


@onready var hp_bar_bg: ColorRect = $Hud/HpBg
@onready var hp_bar: ColorRect = $Hud/HpBar
@onready var name_label: Label = $Hud/NameLabel


var player_id := 1
var move_left_action: StringName
var move_right_action: StringName
var jump_action: StringName
var shoot_action: StringName

var move_speed := 250.0
var jump_force := -650.0
var gravity := 1000.0
var shoot_cooldown := 0.3
var max_health := 5

var health: int = max_health
var _shoot_timer := 0.0
var _facing_right := true

var carried_token: Area2D = null
var spawn_position: Vector2

var teleport_cooldown := 10.0
var _teleport_ready := true
var _teleport_timer := 0.0

# --- Tesla ability state ---
var tesla_field_cooldown := 5.0
var _tesla_field_ready := true
var _tesla_field_timer := 0.0

# --- Joan ability state ---
var joan_shield_cooldown := 6.0
var _joan_shield_ready := true
var _joan_shield_timer := 0.0
var _joan_shield_instance: Node2D = null

const BULLET_SCENE := preload("res://Bullet.tscn")
const SWORD_SLASH_SCENE := preload("res://SwordSlash.tscn")


const TESLA_FIELD_SCENE := preload("res://TeslaField.tscn")
const RADIANT_SHIELD_SCENE := preload("res://RadiantShield.tscn")

func _ready() -> void:
    spawn_position = global_position
    health = max_health
    _update_local_ui()
    _update_visuals_from_character_type()
    _update_sprite_facing()

func _physics_process(delta: float) -> void:
    _apply_gravity(delta)
    _handle_movement(delta)
    _handle_jump()
    _handle_shoot(delta)
    _handle_teleport_input()
    _handle_ability_input()
    _update_teleport_cooldown(delta)
    _update_character_abilities(delta)
    move_and_slide()
    _update_local_ui()

func _apply_gravity(delta: float) -> void:
    if not is_on_floor():
        velocity.y += gravity * delta

func _handle_movement(_delta: float) -> void:
    var dir := 0.0
    if move_left_action != StringName("") and Input.is_action_pressed(move_left_action):
        dir -= 1.0
    if move_right_action != StringName("") and Input.is_action_pressed(move_right_action):
        dir += 1.0

    var speed := move_speed
    # 25% slower while carrying a token
    if carried_token != null and is_instance_valid(carried_token):
        speed *= 0.75

    velocity.x = dir * speed

    if dir > 0.0:
        _facing_right = true
    elif dir < 0.0:
        _facing_right = false
    _update_sprite_facing()

func _handle_jump() -> void:
    if Input.is_action_just_pressed(jump_action) and is_on_floor():
        velocity.y = jump_force

func _handle_shoot(delta: float) -> void:
    if _shoot_timer > 0.0:
        _shoot_timer -= delta

    if shoot_action == StringName(""):
        return

    if Input.is_action_just_pressed(shoot_action) and _shoot_timer <= 0.0:
        _shoot_timer = shoot_cooldown

        match character_type:
            CharacterType.TESLA:
                _spawn_tesla_bolt()
            CharacterType.JOAN:
                _spawn_joan_slash()
            _:
                _spawn_bullet()

func _spawn_bullet() -> void:
    var bullet := BULLET_SCENE.instantiate()
    if bullet == null:
        return

    var offset := Vector2(23, -10)
    if not _facing_right:
        offset.x *= -1.0

    bullet.global_position = global_position + offset
    bullet.direction = Vector2.RIGHT if _facing_right else Vector2.LEFT
    bullet.owner_id = player_id

    var world := get_tree().current_scene.get_node("World")
    if world != null:
        world.add_child(bullet)
    else:
        get_tree().current_scene.add_child(bullet)


func _spawn_tesla_bolt() -> void:
    var bullet := BULLET_SCENE.instantiate()
    if bullet == null:
        return

    var offset := Vector2(23, -10)
    if not _facing_right:
        offset.x *= -1.0

    bullet.global_position = global_position + offset
    bullet.direction = Vector2.RIGHT if _facing_right else Vector2.LEFT
    bullet.owner_id = player_id

    if bullet.has_method("set_is_lightning"):
        bullet.set_is_lightning(true)

    var world := get_tree().current_scene.get_node("World")
    if world != null:
        world.add_child(bullet)
    else:
        get_tree().current_scene.add_child(bullet)



func _spawn_joan_slash() -> void:
    var slash := SWORD_SLASH_SCENE.instantiate()
    if slash == null:
        return

    var offset := Vector2(23, -10)
    if not _facing_right:
        offset.x *= -1.0

    slash.global_position = global_position + offset

    # Flip visual when facing left
    var sprite_node := slash.get_node_or_null("Sprite")
    if sprite_node is Sprite2D and not _facing_right:
        sprite_node.flip_h = true

    if slash.has_method("set_owner_id"):
        slash.set_owner_id(player_id)
    elif slash.has_variable("owner_id"):
        slash.owner_id = player_id

    var world := get_tree().current_scene.get_node("World")
    if world != null:
        world.add_child(slash)
    else:
        get_tree().current_scene.add_child(slash)


func _spawn_joan_projectile() -> void:

    var bullet := BULLET_SCENE.instantiate()
    if bullet == null:
        return

    var offset := Vector2(23, -10)
    if not _facing_right:
        offset.x *= -1.0

    bullet.global_position = global_position + offset
    bullet.direction = Vector2.RIGHT if _facing_right else Vector2.LEFT
    bullet.owner_id = player_id

    if bullet.has_method("set_joan_stats"):
        bullet.set_joan_stats()

    var world := get_tree().current_scene.get_node("World")
    if world != null:
        world.add_child(bullet)
    else:
        get_tree().current_scene.add_child(bullet)

func _handle_teleport_input() -> void:
    var action_name := ""
    if player_id == 1:
        action_name = "p1_teleport"
    elif player_id == 2:
        action_name = "p2_teleport"

    if action_name == "":
        return

    if Input.is_action_just_pressed(action_name) and can_teleport():
        var game := get_tree().get_first_node_in_group("game_manager")
        if game != null:
            game.call("on_player_requested_teleport", self)

func _update_teleport_cooldown(delta: float) -> void:
    if not _teleport_ready:
        _teleport_timer -= delta
        if _teleport_timer <= 0.0:
            _teleport_ready = true
            _teleport_timer = 0.0

func _handle_ability_input() -> void:
    var action_name := ""
    if player_id == 1:
        action_name = "p1_ability"
    elif player_id == 2:
        action_name = "p2_ability"

    if action_name == "":
        return

    if not InputMap.has_action(action_name):
        return

    if not Input.is_action_just_pressed(action_name):
        return

    print("DEBUG ABILITY pressed", action_name, "for player", player_id)

    match character_type:
        CharacterType.TESLA:
            _handle_tesla_special()
        CharacterType.JOAN:
            _handle_joan_special()
        _:
            pass


func _handle_tesla_special() -> void:
    print("DEBUG ABILITY Tesla special")
    if not _tesla_field_ready:
        return

    _tesla_field_ready = false
    _tesla_field_timer = tesla_field_cooldown

    var field := TESLA_FIELD_SCENE.instantiate()
    if field == null:
        return

    field.global_position = global_position

    if field.has_method("set_field_owner"):
        field.set_field_owner(self)

    var world := get_tree().current_scene.get_node("World")
    if world != null:
        world.add_child(field)
    else:
        get_tree().current_scene.add_child(field)


func _handle_joan_special() -> void:
    print("DEBUG ABILITY Joan special")
    if not _joan_shield_ready:
        return
    if _joan_shield_instance != null and is_instance_valid(_joan_shield_instance):
        return

    _joan_shield_ready = false
    _joan_shield_timer = joan_shield_cooldown

    var shield := RADIANT_SHIELD_SCENE.instantiate()
    if shield == null:
        return

    shield.position = Vector2(24, -8)
    if not _facing_right:
        shield.position.x *= -1.0

    add_child(shield)
    _joan_shield_instance = shield
    if shield.has_method("init_shield"):
        shield.init_shield(self, _facing_right)


func get_ability_cooldown_ratio() -> float:
    match character_type:
        CharacterType.TESLA:
            if _tesla_field_ready:
                return 0.0
            if tesla_field_cooldown <= 0.0:
                return 0.0
            return clamp(_tesla_field_timer / tesla_field_cooldown, 0.0, 1.0)
        CharacterType.JOAN:
            if _joan_shield_ready:
                return 0.0
            if joan_shield_cooldown <= 0.0:
                return 0.0
            return clamp(_joan_shield_timer / joan_shield_cooldown, 0.0, 1.0)
        _:
            return 0.0

func _update_character_abilities(delta: float) -> void:
    # Clean up shield reference if it was freed
    if _joan_shield_instance != null and not is_instance_valid(_joan_shield_instance):
        _joan_shield_instance = null

    match character_type:
        CharacterType.TESLA:
            if not _tesla_field_ready:
                _tesla_field_timer -= delta
                if _tesla_field_timer <= 0.0:
                    _tesla_field_ready = true
                    _tesla_field_timer = 0.0
        CharacterType.JOAN:
            if not _joan_shield_ready:
                _joan_shield_timer -= delta
                if _joan_shield_timer <= 0.0:
                    _joan_shield_ready = true
                    _joan_shield_timer = 0.0
        _:
            pass


func _update_local_ui() -> void:
    if hp_bar != null:
        var max_w := hp_bar_bg.size.x if hp_bar_bg != null else 60.0
        var ratio := 0.0
        if max_health > 0:
            ratio = float(health) / float(max_health)
        ratio = clamp(ratio, 0.0, 1.0)
        hp_bar.size.x = max_w * ratio

    if name_label != null:
        match character_type:
            CharacterType.JOAN:
                name_label.text = "Joan of Arc"
            CharacterType.TESLA:
                name_label.text = "Nikola Tesla"
            _:
                name_label.text = "Unknown"


func _update_visuals_from_character_type() -> void:
    if sprite == null:
        return

    match character_type:
        CharacterType.JOAN:
            sprite.texture = TEX_JOAN_IDLE
            # Joan ~5%% smaller so her feet sit cleanly on platforms
            sprite.scale = Vector2(0.09, 0.09)
        CharacterType.TESLA:
            sprite.texture = TEX_TESLA_IDLE
            sprite.scale = Vector2(0.1, 0.1)
        _:
            sprite.texture = TEX_JOAN_IDLE
            sprite.scale = Vector2(0.1, 0.1)


func _update_sprite_facing() -> void:
    if sprite == null:
        return

    sprite.flip_h = not _facing_right



func get_teleport_cooldown_ratio() -> float:
    if _teleport_ready:
        return 0.0
    if teleport_cooldown <= 0.0:
        return 0.0
    return clamp(_teleport_timer / teleport_cooldown, 0.0, 1.0)

func can_teleport() -> bool:
    return _teleport_ready

func consume_teleport() -> void:
    _teleport_ready = false
    _teleport_timer = teleport_cooldown

func get_teleport_time_remaining() -> float:
    return _teleport_timer

func take_hit(from_id: int) -> void:
    health -= 1
    if health <= 0:
        died.emit(from_id, player_id)