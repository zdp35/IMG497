extends Area2D
class_name Bullet

@export var speed := 600.0
@export var knockback_force := 350.0
@export var max_travel_distance := 6000.0

var direction := Vector2.RIGHT
var owner_id := 0
var start_pos: Vector2

@onready var sprite: Sprite2D = $Sprite

var is_lightning := false
var is_joan_bullet := false

func _ready() -> void:
	start_pos = global_position
	area_entered.connect(_on_area_entered)
	body_entered.connect(_on_body_entered)
	add_to_group("actors")

func _physics_process(delta: float) -> void:
	if not is_inside_tree():
		return
	if not is_physics_processing():
		return

	position += direction * speed * delta

	if global_position.distance_to(start_pos) > max_travel_distance:
		queue_free()



func set_is_lightning(flag: bool) -> void:
	is_lightning = flag
	var sprite := get_node_or_null("Sprite")
	if sprite != null:
		if is_lightning:
			# Tesla bullets: blue tint
			sprite.modulate = Color(0.4, 0.7, 1.0, 1.0)
		else:
			# Default bullet: neutral
			sprite.modulate = Color(1, 1, 1, 1)

func set_joan_stats() -> void:
	is_joan_bullet = true
	speed = 450.0
	knockback_force = 450.0

func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("joan_shield"):
		if area.has_method("reflect_bullet"):
			area.reflect_bullet(self)
		return


func _on_body_entered(body: Node) -> void:
	if body.is_in_group("joan_shield"):
		if body.has_method("reflect_bullet"):
			body.reflect_bullet(self)
		return

	if body is Player:
		var p: Player = body
		if p.player_id != owner_id:
			var dir := direction.normalized()
			p.velocity += dir * knockback_force
			p.take_hit(owner_id)
			queue_free()
