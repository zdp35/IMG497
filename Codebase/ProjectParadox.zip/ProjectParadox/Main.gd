extends Node2D

const PLAYER_SCENE = preload("res://Player.tscn")

const HP_BAR_WIDTH := 200.0
const HP_BAR_HEIGHT := 16.0

const COOLDOWN_BAR_WIDTH := 80.0
const COOLDOWN_BAR_HEIGHT := 6.0

const STAGE_WIDTH := 8000.0
const STAGE_BOTTOM_Y := 620.0
const STAGE_MID_Y := 430.0
const STAGE_TOP_Y := 260.0

const TOKENS_TO_WIN := 2
const CAPTURE_RADIUS := 64.0

const STAGE_BG_PATHS := [
	"res://backgrounds/bg_ruins_sunset.png", # green
	"res://backgrounds/bg_castle_night.png", # rock
	"res://backgrounds/bg_ice_coast.png",    # blue
]


@onready var world: Node2D = $World
@onready var viewport_p1: SubViewport = $Views/HSplit/ViewportContainerP1/SubViewportP1
@onready var viewport_p2: SubViewport = $Views/HSplit/ViewportContainerP2/SubViewportP2
@onready var camera_p1: Camera2D = $Views/HSplit/ViewportContainerP1/SubViewportP1/CameraP1
@onready var camera_p2: Camera2D = $Views/HSplit/ViewportContainerP2/SubViewportP2/CameraP2
@onready var ui_layer: CanvasLayer = $UILayer

var p1: Player
var p2: Player

var score_label: Label
var stage_label: Label
var hp_label: Label

var p1_hp_bar: ColorRect
var p2_hp_bar: ColorRect

var p1_view_score_label: Label
var p2_view_score_label: Label
var p1_view_ability_bar: ColorRect
var p1_view_teleport_bar: ColorRect
var p2_view_ability_bar: ColorRect
var p2_view_teleport_bar: ColorRect

var teleport_panel: Panel
var pause_layer: CanvasLayer
var pause_panel: Panel

var scores := {
	1: 0,
	2: 0,
}

var token_scores := {
	1: 0,
	2: 0,
}

var teleporting_player: Player = null

var stage_token_positions := {
	0: Vector2.ZERO,
	1: Vector2.ZERO,
	2: Vector2.ZERO,
}

var stage_token_collected := {
	0: false,
	1: false,
	2: false,
}

var current_token_stage := 0

var stages := [0, 1, 2]
var current_stage_index: int = 0

var stage_nodes: Array = []
var hazard_nodes: Array = []
var stage_tokens := {0: null, 1: null, 2: null}
var token_spots: Array = [[], [], []]
var token_to_stage := {}
var stage_roots: Array[Node2D] = []
var current_platform_texture: Texture2D = null
var stage_world_offsets := {
	0: Vector2(-STAGE_WIDTH * 1.5, 0.0),
	1: Vector2(0.0, 0.0),
	2: Vector2(STAGE_WIDTH * 1.5, 0.0),
}
var current_stage_root: Node2D = null
var p1_stage_index: int = 0
var p2_stage_index: int = 0

# Centers of capture rings in local stage coordinates
var capture_zones := {
	0: [],
	1: [],
	2: [],
}

var is_game_paused := false


func _ready() -> void:
	randomize()
	add_to_group("game_manager")
	_setup_input()
	_setup_viewports()
	_create_ui()
	_create_pause_menu()
	_create_players()
	_create_stage_roots()
	_init_stage_tokens()
	_build_all_stages()
	_create_capture_rings()
	_respawn_players()
	for i in range(stages.size()):
		_create_token_random(i)
	set_process(true)


func _process(delta: float) -> void:
	if is_game_paused:
		return
	_update_ui()
	_update_split_screen_cameras(delta)
	_update_token_state(delta)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause"):
		_toggle_pause()
		get_viewport().set_input_as_handled()


func _setup_viewports() -> void:
	var root_vp := get_viewport()
	viewport_p1.world_2d = root_vp.world_2d
	viewport_p2.world_2d = root_vp.world_2d

	if camera_p1:
		camera_p1.zoom = Vector2(0.5, 0.5)
	if camera_p2:
		camera_p2.zoom = Vector2(0.5, 0.5)


func _setup_input() -> void:
	_add_key_action("p1_left", Key.KEY_A)
	_add_key_action("p1_right", Key.KEY_D)
	_add_key_action("p1_jump", Key.KEY_W)
	_add_key_action("p1_shoot", Key.KEY_F)

	_add_key_action("p2_left", Key.KEY_LEFT)
	_add_key_action("p2_right", Key.KEY_RIGHT)
	_add_key_action("p2_jump", Key.KEY_UP)
	_add_key_action("p2_shoot", Key.KEY_M)
	_add_key_action("p1_teleport", Key.KEY_Q)
	_add_key_action("p2_teleport", Key.KEY_SLASH)
	_add_key_action("p1_ability", Key.KEY_E)
	_add_key_action("p2_ability", Key.KEY_K)

	if not InputMap.has_action("pause"):
		InputMap.add_action("pause")
	var ev := InputEventKey.new()
	ev.physical_keycode = Key.KEY_ESCAPE
	InputMap.action_add_event("pause", ev)


func _add_key_action(action_name: StringName, key: Key) -> void:
	if not InputMap.has_action(action_name):
		InputMap.add_action(action_name)
	var ev := InputEventKey.new()
	ev.physical_keycode = key
	InputMap.action_add_event(action_name, ev)


func _create_stage_roots() -> void:
	stage_roots.clear()
	for i in range(stages.size()):
		var root := Node2D.new()
		root.name = "StageRoot_%d" % i
		root.position = stage_world_offsets.get(i, Vector2.ZERO)
		world.add_child(root)
		stage_roots.append(root)


func _create_stage_background(stage_index: int) -> void:
	if stage_index < 0 or stage_index >= STAGE_BG_PATHS.size():
		return
	if stage_index >= stage_roots.size():
		return

	var root := stage_roots[stage_index]
	if root == null:
		return

	# Panoramic repeat with smaller tiles (more zoomed out)
	var tile_offsets := [-2, -1, 0, 1, 2]
	var tile_width := STAGE_WIDTH * 0.2
	var tile_height := 2200.0

	# Place the background so it spans vertically around the stage area
	var vertical_center := STAGE_BOTTOM_Y - tile_height * 0.3

	for k in tile_offsets:
		var bg := Sprite2D.new()
		bg.name = "Background_%d" % k
		bg.z_index = -10
		bg.texture = load(STAGE_BG_PATHS[stage_index])
		if bg.texture != null:
			var tex_size: Vector2 = bg.texture.get_size()
			if tex_size.x != 0.0 and tex_size.y != 0.0:
				bg.scale = Vector2(tile_width, tile_height) / tex_size
		bg.position = Vector2(k * tile_width, vertical_center)
		bg.modulate = Color(1, 1, 1)
		root.add_child(bg)


func _build_all_stages() -> void:
	stage_nodes.clear()
	hazard_nodes.clear()
	for i in range(stages.size()):
		if i >= stage_roots.size():
			continue
		current_stage_root = stage_roots[i]
		match i:
			0:
				current_platform_texture = load("res://art/platform_grass.png")
				_create_stage_background(0)
				_build_green_stage()
			1:
				current_platform_texture = load("res://art/platform_rock.png")
				_create_stage_background(1)
				_build_rock_stage()
			2:
				current_platform_texture = load("res://art/platform_snow_rock.png")
				_create_stage_background(2)
				_build_blue_stage()
	current_stage_root = null


func _create_capture_rings() -> void:
	var radius := CAPTURE_RADIUS
	var half_w := STAGE_WIDTH * 0.5
	var margin := 300.0

	for i in range(stages.size()):
		if i >= stage_roots.size():
			continue
		var root := stage_roots[i]
		if root == null:
			continue

		var y := STAGE_MID_Y - 60.0
		var left_local := Vector2(-half_w + margin, y)
		var right_local := Vector2(half_w - margin, y)

		_create_capture_ring(root, left_local, radius)
		_create_capture_ring(root, right_local, radius)

		capture_zones[i] = [left_local, right_local]


func _create_capture_ring(root: Node2D, center: Vector2, radius: float) -> void:
	var ring := Line2D.new()
	ring.width = 4.0
	ring.default_color = Color(1.0, 0.9, 0.2, 1.0)
	var segments := 64
	for i in range(segments + 1):
		var angle := TAU * float(i) / float(segments)
		var pt := center + Vector2(cos(angle), sin(angle)) * radius
		ring.add_point(pt)
	ring.z_index = -5
	root.add_child(ring)


func _create_ui() -> void:
	# Global score + stage labels (top-left)
	score_label = Label.new()
	score_label.position = Vector2(16, 16)
	score_label.text = "P1: 0   P2: 0"
	ui_layer.add_child(score_label)

	stage_label = Label.new()
	stage_label.position = Vector2(16, 36)
	ui_layer.add_child(stage_label)

	# Teleport arena selection panel (top-right, hidden by default)
	teleport_panel = Panel.new()
	teleport_panel.anchor_left = 1.0
	teleport_panel.anchor_right = 1.0
	teleport_panel.anchor_top = 0.0
	teleport_panel.anchor_bottom = 0.0
	teleport_panel.offset_left = -220.0
	teleport_panel.offset_right = -20.0
	teleport_panel.offset_top = 16.0
	teleport_panel.offset_bottom = 140.0
	teleport_panel.visible = false
	ui_layer.add_child(teleport_panel)

	var vb := VBoxContainer.new()
	vb.anchor_left = 0.0
	vb.anchor_top = 0.0
	vb.anchor_right = 1.0
	vb.anchor_bottom = 1.0
	vb.offset_left = 10.0
	vb.offset_top = 10.0
	vb.offset_right = -10.0
	vb.offset_bottom = -10.0
	teleport_panel.add_child(vb)

	var label := Label.new()
	label.text = "Teleport arena:"
	vb.add_child(label)

	var btn_green := Button.new()
	btn_green.text = "Go to Green"
	btn_green.pressed.connect(_on_btn_green_pressed)
	vb.add_child(btn_green)

	var btn_rock := Button.new()
	btn_rock.text = "Go to Rock"
	btn_rock.pressed.connect(_on_btn_rock_pressed)
	vb.add_child(btn_rock)

	var btn_blue := Button.new()
	btn_blue.text = "Go to Blue"
	btn_blue.pressed.connect(_on_btn_blue_pressed)
	vb.add_child(btn_blue)

	# Per-viewport HUDs
	var p1_container: SubViewportContainer = $Views/HSplit/ViewportContainerP1
	var p2_container: SubViewportContainer = $Views/HSplit/ViewportContainerP2

	# Left viewport (P1)
	p1_view_score_label = Label.new()
	p1_view_score_label.text = "P1 Tokens: 0"
	p1_view_score_label.anchor_left = 0.0
	p1_view_score_label.anchor_top = 0.0
	p1_view_score_label.anchor_right = 0.0
	p1_view_score_label.anchor_bottom = 0.0
	p1_view_score_label.position = Vector2(10, 10)
	p1_container.add_child(p1_view_score_label)

	p1_view_ability_bar = ColorRect.new()
	p1_view_ability_bar.position = Vector2(10, 30)
	p1_view_ability_bar.size = Vector2(COOLDOWN_BAR_WIDTH, COOLDOWN_BAR_HEIGHT)
	p1_view_ability_bar.color = Color(0.2, 0.6, 1.0)
	p1_container.add_child(p1_view_ability_bar)

	p1_view_teleport_bar = ColorRect.new()
	p1_view_teleport_bar.position = Vector2(10, 42)
	p1_view_teleport_bar.size = Vector2(COOLDOWN_BAR_WIDTH, COOLDOWN_BAR_HEIGHT)
	p1_view_teleport_bar.color = Color(0.8, 0.8, 0.2)
	p1_container.add_child(p1_view_teleport_bar)

	# Right viewport (P2)
	p2_view_score_label = Label.new()
	p2_view_score_label.text = "P2 Tokens: 0"
	p2_view_score_label.anchor_left = 0.0
	p2_view_score_label.anchor_top = 0.0
	p2_view_score_label.anchor_right = 0.0
	p2_view_score_label.anchor_bottom = 0.0
	p2_view_score_label.position = Vector2(10, 10)
	p2_container.add_child(p2_view_score_label)

	p2_view_ability_bar = ColorRect.new()
	p2_view_ability_bar.position = Vector2(10, 30)
	p2_view_ability_bar.size = Vector2(COOLDOWN_BAR_WIDTH, COOLDOWN_BAR_HEIGHT)
	p2_view_ability_bar.color = Color(0.2, 0.6, 1.0)
	p2_container.add_child(p2_view_ability_bar)

	p2_view_teleport_bar = ColorRect.new()
	p2_view_teleport_bar.position = Vector2(10, 42)
	p2_view_teleport_bar.size = Vector2(COOLDOWN_BAR_WIDTH, COOLDOWN_BAR_HEIGHT)
	p2_view_teleport_bar.color = Color(0.8, 0.8, 0.2)
	p2_container.add_child(p2_view_teleport_bar)

func _create_pause_menu() -> void:
	pause_layer = CanvasLayer.new()
	pause_layer.layer = 10
	add_child(pause_layer)

	pause_panel = Panel.new()
	pause_panel.visible = false
	pause_panel.anchor_left = 0.5
	pause_panel.anchor_top = 0.5
	pause_panel.anchor_right = 0.5
	pause_panel.anchor_bottom = 0.5
	pause_panel.offset_left = -160.0
	pause_panel.offset_top = -100.0
	pause_panel.offset_right = 160.0
	pause_panel.offset_bottom = 100.0
	pause_layer.add_child(pause_panel)

	var vb := VBoxContainer.new()
	vb.anchor_left = 0.0
	vb.anchor_top = 0.0
	vb.anchor_right = 1.0
	vb.anchor_bottom = 1.0
	vb.offset_left = 12.0
	vb.offset_top = 12.0
	vb.offset_right = -12.0
	vb.offset_bottom = -12.0
	pause_panel.add_child(vb)

	var label := Label.new()
	label.text = "Paused"
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", 22)
	vb.add_child(label)

	var resume_btn := Button.new()
	resume_btn.text = "Resume"
	resume_btn.pressed.connect(_on_pause_resume)
	vb.add_child(resume_btn)

	var title_btn := Button.new()
	title_btn.text = "Quit to Title"
	title_btn.pressed.connect(_on_pause_quit_to_title)
	vb.add_child(title_btn)


func _set_game_paused(paused: bool) -> void:
	is_game_paused = paused
	if pause_panel != null:
		pause_panel.visible = paused
	if teleport_panel != null and paused:
		teleport_panel.visible = false

	var actors := get_tree().get_nodes_in_group("actors")
	for n in actors:
		if n is Node:
			n.set_physics_process(not paused)


func _toggle_pause() -> void:
	_set_game_paused(not is_game_paused)


func _on_pause_resume() -> void:
	_set_game_paused(false)


func _on_pause_quit_to_title() -> void:
	_set_game_paused(false)
	get_tree().change_scene_to_file("res://Title.tscn")


func _create_players() -> void:
	p1 = _create_player(
		Vector2(-600, STAGE_MID_Y - 40.0),
		Color(0.9, 0.3, 0.3),
		1,
		"p1_left",
		"p1_right",
		"p1_jump",
		"p1_shoot"
	)

	p2 = _create_player(
		Vector2(600, STAGE_MID_Y - 40.0),
		Color(0.3, 0.3, 0.9),
		2,
		"p2_left",
		"p2_right",
		"p2_jump",
		"p2_shoot"
	)

	var g := get_tree().root.get_node_or_null("Globals")
	var p1_type := Player.CharacterType.JOAN
	var p2_type := Player.CharacterType.TESLA
	if g != null:
		if g.p1_character == "TESLA":
			p1_type = Player.CharacterType.TESLA
		elif g.p1_character == "JOAN":
			p1_type = Player.CharacterType.JOAN

		if g.p2_character == "TESLA":
			p2_type = Player.CharacterType.TESLA
		elif g.p2_character == "JOAN":
			p2_type = Player.CharacterType.JOAN

	p1.set_character_type(p1_type)
	p2.set_character_type(p2_type)

	p1.died.connect(_on_player_died)
	p2.died.connect(_on_player_died)

	if camera_p1 != null:
		camera_p1.position = p1.global_position
		camera_p1.make_current()
	if camera_p2 != null:
		camera_p2.position = p2.global_position
		camera_p2.make_current()


func _create_player(start_pos: Vector2, color: Color, id: int,
	left_action: StringName, right_action: StringName,
	jump_action: StringName, shoot_action: StringName) -> Player:
	var player: Player = PLAYER_SCENE.instantiate()
	player.position = start_pos
	player.player_id = id
	player.move_left_action = left_action
	player.move_right_action = right_action
	player.jump_action = jump_action
	player.shoot_action = shoot_action

	var sprite: Sprite2D = player.get_node("Sprite")
	if sprite != null:
		sprite.modulate = Color(1, 1, 1, 1)

	var shape := RectangleShape2D.new()
	shape.extents = Vector2(16, 22)
	var collider := CollisionShape2D.new()
	collider.shape = shape
	player.add_child(collider)

	player.add_to_group("actors")

	world.add_child(player)
	return player


func _load_stage(index: int) -> void:
	current_stage_index = index
	_apply_stage_movement_settings()
	_update_ui()


func _build_green_stage() -> void:
	var color := Color(0.05, 0.35, 0.08)

	stage_nodes.append(_create_floor(Vector2(0, STAGE_BOTTOM_Y), STAGE_WIDTH, 38.0, color))

	stage_nodes.append(_create_floor(Vector2(-1800, STAGE_MID_Y + 70.0), 700.0, 24.0, color))
	stage_nodes.append(_create_floor(Vector2(-600, STAGE_MID_Y + 40.0), 550.0, 24.0, color))
	stage_nodes.append(_create_floor(Vector2(600, STAGE_MID_Y + 40.0), 550.0, 24.0, color))
	stage_nodes.append(_create_floor(Vector2(1800, STAGE_MID_Y + 70.0), 700.0, 24.0, color))

	stage_nodes.append(_create_floor(Vector2(-1000, STAGE_MID_Y), 500.0, 22.0, color))
	stage_nodes.append(_create_floor(Vector2(0, STAGE_MID_Y - 20.0), 700.0, 24.0, color))
	stage_nodes.append(_create_floor(Vector2(1000, STAGE_MID_Y), 500.0, 22.0, color))

	stage_nodes.append(_create_floor(Vector2(-1600, STAGE_TOP_Y + 70.0), 550.0, 22.0, color))
	stage_nodes.append(_create_floor(Vector2(1600, STAGE_TOP_Y + 70.0), 550.0, 22.0, color))

	stage_nodes.append(_create_floor(Vector2(0, STAGE_TOP_Y), 420.0, 20.0, color))

	# Extra far-left and far-right lower platforms
	stage_nodes.append(_create_floor(Vector2(-2600, STAGE_BOTTOM_Y - 40.0), 650.0, 26.0, color))
	stage_nodes.append(_create_floor(Vector2(2600, STAGE_BOTTOM_Y - 40.0), 650.0, 26.0, color))

	# Extra mid-height outer platforms
	stage_nodes.append(_create_floor(Vector2(-2700, STAGE_MID_Y - 30.0), 520.0, 22.0, color))
	stage_nodes.append(_create_floor(Vector2(2700, STAGE_MID_Y - 30.0), 520.0, 22.0, color))

	# Extra high outer platforms
	stage_nodes.append(_create_floor(Vector2(-2900, STAGE_TOP_Y + 40.0), 420.0, 20.0, color))
	stage_nodes.append(_create_floor(Vector2(2900, STAGE_TOP_Y + 40.0), 420.0, 20.0, color))

	token_spots[0] = [
		Vector2(0, STAGE_TOP_Y - 40.0),
		Vector2(0, STAGE_MID_Y - 40.0),
		Vector2(0, STAGE_BOTTOM_Y - 80.0),
	]

	# Fog that covers the stage vertical span
	var fog_center := Vector2(0, (STAGE_BOTTOM_Y + STAGE_TOP_Y) * 0.5)
	_create_fog(fog_center, STAGE_WIDTH)


func _build_rock_stage() -> void:
	var color := Color(0.4, 0.35, 0.3)

	stage_nodes.append(_create_floor(Vector2(0, STAGE_BOTTOM_Y), STAGE_WIDTH, 44.0, color))

	stage_nodes.append(_create_floor(Vector2(-1900, STAGE_BOTTOM_Y - 70.0), 650.0, 26.0, color))
	stage_nodes.append(_create_floor(Vector2(-800, STAGE_BOTTOM_Y - 110.0), 600.0, 24.0, color))
	stage_nodes.append(_create_floor(Vector2(300, STAGE_BOTTOM_Y - 140.0), 600.0, 24.0, color))
	stage_nodes.append(_create_floor(Vector2(1500, STAGE_BOTTOM_Y - 170.0), 650.0, 24.0, color))

	stage_nodes.append(_create_floor(Vector2(-1500, STAGE_MID_Y - 10.0), 550.0, 22.0, color))
	stage_nodes.append(_create_floor(Vector2(-400, STAGE_MID_Y - 40.0), 600.0, 22.0, color))
	stage_nodes.append(_create_floor(Vector2(800, STAGE_MID_Y - 70.0), 600.0, 22.0, color))
	stage_nodes.append(_create_floor(Vector2(1900, STAGE_MID_Y - 90.0), 550.0, 22.0, color))

	stage_nodes.append(_create_floor(Vector2(-900, STAGE_TOP_Y + 30.0), 550.0, 20.0, color))
	stage_nodes.append(_create_floor(Vector2(0, STAGE_TOP_Y + 10.0), 650.0, 20.0, color))
	stage_nodes.append(_create_floor(Vector2(900, STAGE_TOP_Y + 30.0), 550.0, 20.0, color))

	stage_nodes.append(_create_floor(Vector2(0, STAGE_TOP_Y), 420.0, 18.0, color))

	# Extra far-left and far-right lower platforms
	stage_nodes.append(_create_floor(Vector2(-2700, STAGE_BOTTOM_Y - 60.0), 700.0, 28.0, color))
	stage_nodes.append(_create_floor(Vector2(2700, STAGE_BOTTOM_Y - 60.0), 700.0, 28.0, color))

	# Extra mid-height outer platforms
	stage_nodes.append(_create_floor(Vector2(-2800, STAGE_MID_Y - 40.0), 540.0, 22.0, color))
	stage_nodes.append(_create_floor(Vector2(2800, STAGE_MID_Y - 40.0), 540.0, 22.0, color))

	# Extra high outer platforms
	stage_nodes.append(_create_floor(Vector2(-3000, STAGE_TOP_Y + 30.0), 420.0, 20.0, color))
	stage_nodes.append(_create_floor(Vector2(3000, STAGE_TOP_Y + 30.0), 420.0, 20.0, color))

	token_spots[1] = [
		Vector2(0, STAGE_TOP_Y - 40.0),
		Vector2(0, STAGE_MID_Y - 40.0),
		Vector2(0, STAGE_BOTTOM_Y - 80.0),
	]


func _build_blue_stage() -> void:
	var color := Color(0.3, 0.4, 0.6)

	stage_nodes.append(_create_floor(Vector2(0, STAGE_BOTTOM_Y), STAGE_WIDTH, 36.0, color))

	stage_nodes.append(_create_floor(Vector2(-1700, STAGE_BOTTOM_Y - 80.0), 520.0, 22.0, color))
	stage_nodes.append(_create_floor(Vector2(-600, STAGE_BOTTOM_Y - 60.0), 420.0, 20.0, color))
	stage_nodes.append(_create_floor(Vector2(600, STAGE_BOTTOM_Y - 60.0), 420.0, 20.0, color))
	stage_nodes.append(_create_floor(Vector2(1700, STAGE_BOTTOM_Y - 80.0), 520.0, 22.0, color))

	stage_nodes.append(_create_floor(Vector2(-1200, STAGE_MID_Y - 10.0), 480.0, 20.0, color))
	stage_nodes.append(_create_floor(Vector2(0, STAGE_MID_Y - 40.0), 520.0, 20.0, color))
	stage_nodes.append(_create_floor(Vector2(1200, STAGE_MID_Y - 10.0), 480.0, 20.0, color))

	stage_nodes.append(_create_floor(Vector2(-800, STAGE_TOP_Y + 40.0), 380.0, 18.0, color))
	stage_nodes.append(_create_floor(Vector2(800, STAGE_TOP_Y + 40.0), 380.0, 18.0, color))

	stage_nodes.append(_create_floor(Vector2(0, STAGE_TOP_Y), 360.0, 18.0, color))

	# Extra far-left and far-right lower platforms
	stage_nodes.append(_create_floor(Vector2(-2700, STAGE_BOTTOM_Y - 50.0), 680.0, 26.0, color))
	stage_nodes.append(_create_floor(Vector2(2700, STAGE_BOTTOM_Y - 50.0), 680.0, 26.0, color))

	# Extra mid-height outer platforms
	stage_nodes.append(_create_floor(Vector2(-2800, STAGE_MID_Y - 35.0), 540.0, 22.0, color))
	stage_nodes.append(_create_floor(Vector2(2800, STAGE_MID_Y - 35.0), 540.0, 22.0, color))

	# Extra high outer platforms
	stage_nodes.append(_create_floor(Vector2(-3000, STAGE_TOP_Y + 35.0), 420.0, 20.0, color))
	stage_nodes.append(_create_floor(Vector2(3000, STAGE_TOP_Y + 35.0), 420.0, 20.0, color))

	token_spots[2] = [
		Vector2(0, STAGE_TOP_Y - 40.0),
		Vector2(0, STAGE_MID_Y - 40.0),
		Vector2(0, STAGE_BOTTOM_Y - 80.0),
	]

	_create_flame_pockets()


func _respawn_player(player: Player) -> void:
	if player == null:
		return

	var stage_index: int = 0
	if player.player_id == 1:
		stage_index = p1_stage_index
	else:
		stage_index = p2_stage_index

	var local_pos: Vector2
	if player.player_id == 1:
		local_pos = Vector2(-600, STAGE_MID_Y - 60.0)
	else:
		local_pos = Vector2(600, STAGE_MID_Y - 60.0)

	if stage_index >= 0 and stage_index < stage_roots.size():
		var root := stage_roots[stage_index]
		if root != null:
			player.global_position = root.to_global(local_pos)
	else:
		player.global_position = local_pos

	player.velocity = Vector2.ZERO
	player.health = player.max_health


func _respawn_players() -> void:
	_respawn_player(p1)
	_respawn_player(p2)
	_apply_stage_movement_settings()
	_update_ui()


func _apply_stage_movement_settings() -> void:
	if p1 == null or p2 == null:
		return

	if current_stage_index == 1:
		p1.move_speed = 160.0
		p2.move_speed = 160.0
	else:
		p1.move_speed = 250.0
		p2.move_speed = 250.0


func _create_floor(center: Vector2, width: float, height: float, color: Color) -> StaticBody2D:
	var ground := StaticBody2D.new()
	ground.position = center

	var shape := RectangleShape2D.new()
	shape.extents = Vector2(width / 2.0, height / 2.0)
	var collider := CollisionShape2D.new()
	collider.shape = shape
	ground.add_child(collider)

	var sprite := Sprite2D.new()
	var tex: Texture2D = current_platform_texture
	if tex == null:
		tex = load("res://white_pixel.png")
	sprite.texture = tex
	if sprite.texture != null:
		var tex_size := sprite.texture.get_size()
		if tex_size.x != 0.0:
			# Stretch horizontally to match platform width, keep pixel-art height
			sprite.scale.x = width / tex_size.x
			sprite.scale.y = 1.0

	# Only tint when using the white pixel debug texture
	if current_platform_texture == null:
		sprite.modulate = color
	else:
		sprite.modulate = Color(1, 1, 1, 1)

	ground.add_child(sprite)

	var parent := current_stage_root if current_stage_root != null else world
	parent.add_child(ground)
	return ground


func _create_fog(center: Vector2, width: float) -> void:
	var fog := Sprite2D.new()

	var grad := Gradient.new()
	grad.colors = [
		Color(0.6, 0.6, 0.6, 0.05),
		Color(0.4, 0.4, 0.4, 0.90),
		Color(0.6, 0.6, 0.6, 0.05),
	]
	grad.offsets = [0.0, 0.5, 1.0]

	# Match vertical span of the stage backgrounds (same as tile_height in _create_stage_background)
	var fog_height := 2200.0

	var grad_tex := GradientTexture2D.new()
	grad_tex.gradient = grad
	grad_tex.width = int(width)
	grad_tex.height = int(fog_height)
	grad_tex.fill = GradientTexture2D.FILL_LINEAR
	grad_tex.fill_from = Vector2(0, 0)
	grad_tex.fill_to = Vector2(1, 0)

	fog.texture = grad_tex

	# Align vertically with the background center used in _create_stage_background
	var vertical_center := STAGE_BOTTOM_Y - fog_height * 0.3
	fog.position = Vector2(center.x, vertical_center)
	fog.z_index = 50

	var parent := current_stage_root if current_stage_root != null else world
	parent.add_child(fog)
	hazard_nodes.append(fog)


func _create_flame_pockets() -> void:
	var y := STAGE_BOTTOM_Y - 28.0
	var xs := [-1600.0, 0.0, 1600.0]

	for x in xs:
		var area := Area2D.new()
		area.position = Vector2(x, y)

		var shape := RectangleShape2D.new()
		shape.extents = Vector2(80, 18)
		var coll := CollisionShape2D.new()
		coll.shape = shape
		area.add_child(coll)

		var spr := Sprite2D.new()
		spr.texture = load("res://white_pixel.png")
		if spr.texture != null:
			var tex_size := spr.texture.get_size()
			if tex_size.x != 0.0 and tex_size.y != 0.0:
				spr.scale = Vector2(160, 36) / tex_size
		spr.modulate = Color(0.2, 0.5, 1.0, 0.9)
		area.add_child(spr)

		var parent := current_stage_root if current_stage_root != null else world
		parent.add_child(area)
		hazard_nodes.append(area)

		area.body_entered.connect(_on_flame_body_entered)


func _create_token_random(stage_index: int) -> void:
	if stage_index < 0 or stage_index >= stages.size():
		return

	if stage_token_collected[stage_index]:
		return

	if stage_tokens.has(stage_index) and stage_tokens[stage_index] != null and is_instance_valid(stage_tokens[stage_index]):
		stage_tokens[stage_index].queue_free()
	stage_tokens[stage_index] = null

	if stage_index >= stage_roots.size():
		return
	var root := stage_roots[stage_index]
	if root == null:
		return

	var local_pos: Vector2 = stage_token_positions[stage_index]
	current_token_stage = stage_index

	var token := Area2D.new()
	token.position = local_pos

	var shape := CircleShape2D.new()
	shape.radius = 12.0
	var coll := CollisionShape2D.new()
	coll.shape = shape
	token.add_child(coll)

	var spr := Sprite2D.new()
	var tex_path := ""
	match stage_index:
		0:
			tex_path = "res://art/token_book.png"
		1:
			tex_path = "res://art/token_sword.png"
		2:
			tex_path = "res://art/token_orb.png"
		_:
			tex_path = "res://white_pixel.png"
	spr.texture = load(tex_path)
	if spr.texture != null:
		var tex_size := spr.texture.get_size()
		if tex_size.x != 0.0 and tex_size.y != 0.0:
			spr.scale = Vector2(3, 3)
	spr.modulate = Color(1, 1, 1, 1)
	token.add_child(spr)

	root.add_child(token)
	stage_tokens[stage_index] = token
	token_to_stage[token] = stage_index
	token.body_entered.connect(_on_token_body_entered.bind(token))

func _init_stage_tokens() -> void:
	var spots := [
		Vector2(0, STAGE_TOP_Y - 40.0),
		Vector2(0, STAGE_MID_Y - 40.0),
		Vector2(0, STAGE_BOTTOM_Y - 80.0),
	]
	var pool := spots.duplicate()
	for i in range(stages.size()):
		if pool.is_empty():
			pool = spots.duplicate()
		var idx := randi() % pool.size()
		stage_token_positions[i] = pool[idx]
		stage_token_collected[i] = false
		pool.remove_at(idx)


func _advance_stage() -> void:
	var next_index := (current_stage_index + 1) % stages.size()
	_switch_to_stage(next_index)


func _switch_to_stage(index: int) -> void:
	if teleporting_player != null:
		var player: Player = teleporting_player

		# Drop any carried token when teleporting so it returns to its spawn stage.
		_drop_player_token(player)

		if player.player_id == 1:
			p1_stage_index = index
		else:
			p2_stage_index = index

		if index >= 0 and index < stage_roots.size():
			var root := stage_roots[index]
			if root != null:
				var local_spawn: Vector2
				if player.player_id == 1:
					local_spawn = Vector2(-600, STAGE_MID_Y - 60.0)
				else:
					local_spawn = Vector2(600, STAGE_MID_Y - 60.0)
				player.global_position = root.to_global(local_spawn)

		player.velocity = Vector2.ZERO
		player.health = player.max_health
		player.consume_teleport()
		teleporting_player = null

	if teleport_panel != null:
		teleport_panel.visible = false

func _update_ui() -> void:
	if p1 == null or p2 == null:
		return

	# Global summary labels
	score_label.text = "Tokens - P1: %d   P2: %d" % [token_scores[1], token_scores[2]]
	stage_label.text = "Stage %d" % (current_stage_index + 1)

	# Per-viewport score labels
	if p1_view_score_label != null:
		p1_view_score_label.text = "P1 Tokens: %d" % token_scores[1]
	if p2_view_score_label != null:
		p2_view_score_label.text = "P2 Tokens: %d" % token_scores[2]

	# Cooldown bars (0.0 = ready, 1.0 = full cooldown)
	var ability_ratio_p1 := 0.0
	var ability_ratio_p2 := 0.0
	var teleport_ratio_p1 := 0.0
	var teleport_ratio_p2 := 0.0

	if p1 != null:
		ability_ratio_p1 = p1.get_ability_cooldown_ratio()
		teleport_ratio_p1 = p1.get_teleport_cooldown_ratio()
	if p2 != null:
		ability_ratio_p2 = p2.get_ability_cooldown_ratio()
		teleport_ratio_p2 = p2.get_teleport_cooldown_ratio()

	# Map ratios into bar width such that full bar = ready, empty = on cooldown
	var w := COOLDOWN_BAR_WIDTH
	if p1_view_ability_bar != null:
		p1_view_ability_bar.size.x = w * (1.0 - clamp(ability_ratio_p1, 0.0, 1.0))
	if p2_view_ability_bar != null:
		p2_view_ability_bar.size.x = w * (1.0 - clamp(ability_ratio_p2, 0.0, 1.0))

	if p1_view_teleport_bar != null:
		p1_view_teleport_bar.size.x = w * (1.0 - clamp(teleport_ratio_p1, 0.0, 1.0))
	if p2_view_teleport_bar != null:
		p2_view_teleport_bar.size.x = w * (1.0 - clamp(teleport_ratio_p2, 0.0, 1.0))

func _drop_player_token(player: Player) -> void:
	if player == null:
		return
	if player.carried_token == null:
		return

	var token: Area2D = player.carried_token as Area2D
	player.carried_token = null

	if token == null or not is_instance_valid(token):
		return

	var stage_index := -1
	if token_to_stage.has(token):
		stage_index = int(token_to_stage[token])

	token.queue_free()

	if stage_index >= 0:
		stage_token_collected[stage_index] = false
		stage_tokens[stage_index] = null
		token_to_stage.erase(token)
		_create_token_random(stage_index)

func _on_player_died(killer_id: int, victim_id: int) -> void:
	if killer_id != 0 and scores.has(killer_id):
		scores[killer_id] += 1

	var victim: Player = null
	if victim_id == 1:
		victim = p1
	elif victim_id == 2:
		victim = p2

	_drop_player_token(victim)
	_respawn_player(victim)

func _on_flame_body_entered(body: Node) -> void:

	if body is Player:
		var p: Player = body
		p.health = 1
		p.take_hit(0)


func _on_token_body_entered(body: Node, token: Area2D) -> void:
	if token == null or not is_instance_valid(token):
		return
	if body is Player:
		var p: Player = body
		if p.carried_token != null:
			return
		p.carried_token = token
		for child in token.get_children():
			if child is CollisionShape2D:
				child.disabled = true


func _on_btn_green_pressed() -> void:
	_switch_to_stage(0)


func _on_btn_rock_pressed() -> void:
	_switch_to_stage(1)


func _on_btn_blue_pressed() -> void:
	_switch_to_stage(2)


func _update_split_screen_cameras(_delta: float) -> void:
	if camera_p1 == null or camera_p2 == null:
		return
	if p1 != null:
		camera_p1.position = p1.global_position
	if p2 != null:
		camera_p2.position = p2.global_position


func on_player_requested_teleport(player: Player) -> void:
	if is_game_paused:
		return
	if player == null:
		return
	if not player.can_teleport():
		return
	teleporting_player = player
	if teleport_panel != null:
		teleport_panel.visible = true


func _update_token_state(_delta: float) -> void:
	for player in [p1, p2]:
		if player == null:
			continue
		if player.carried_token == null or not is_instance_valid(player.carried_token):
			continue

		var token: Area2D = player.carried_token as Area2D
		if token == null:
			continue

		# Token follows above the carrier
		var offset := Vector2(0.0, -48.0)
		token.global_position = player.global_position + offset

		# Use the player's current stage, not token's spawn stage
		var player_stage_index := 0
		if player.player_id == 1:
			player_stage_index = p1_stage_index
		else:
			player_stage_index = p2_stage_index

		if player_stage_index < 0 or player_stage_index >= stage_roots.size():
			continue

		var root := stage_roots[player_stage_index]
		if root == null:
			continue
		if not capture_zones.has(player_stage_index):
			continue

		var zone_list: Array = capture_zones[player_stage_index]
		for local_center in zone_list:
			var global_center := root.to_global(local_center)
			if player.global_position.distance_to(global_center) <= CAPTURE_RADIUS:
				player.carried_token = null
				_on_token_captured(player, token)
				break


func _on_token_captured(player: Player, token: Area2D) -> void:
	if player == null:
		return
	if not token_scores.has(player.player_id):
		return
	if token == null or not is_instance_valid(token):
		return

	var stage_index := -1
	if token_to_stage.has(token):
		stage_index = int(token_to_stage[token])

	token_scores[player.player_id] += 1

	if stage_index >= 0:
		stage_token_collected[stage_index] = true
		stage_tokens[stage_index] = null

	token.queue_free()
	token_to_stage.erase(token)

	if token_scores[player.player_id] >= TOKENS_TO_WIN:
		_on_match_won(player.player_id)
	else:
		_respawn_players()
		if stage_index >= 0 and stage_index < stages.size() and not stage_token_collected[stage_index]:
			_create_token_random(stage_index)


func _on_match_won(winner_id: int) -> void:
	print("Player %d wins the match!" % winner_id)
	token_scores[1] = 0
	token_scores[2] = 0
	scores[1] = 0
	scores[2] = 0

	var spots := [
		Vector2(0, STAGE_TOP_Y - 40.0),
		Vector2(0, STAGE_MID_Y - 40.0),
		Vector2(0, STAGE_BOTTOM_Y - 80.0),
	]
	var pool := spots.duplicate()
	for i in range(stages.size()):
		if pool.is_empty():
			pool = spots.duplicate()
		var idx := randi() % pool.size()
		stage_token_positions[i] = pool[idx]
		stage_token_collected[i] = false
		pool.remove_at(idx)

	for i in range(stages.size()):
		_create_token_random(i)

	_respawn_players()
