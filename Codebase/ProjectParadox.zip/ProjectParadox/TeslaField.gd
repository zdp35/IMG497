extends Area2D
class_name TeslaField

@export var lifetime := 3.0
@export var tick_interval := 0.4

var _owner: Player = null
var _time_left := 0.0
var _tick_timer := 0.0

func _ready() -> void:
	_time_left = lifetime
	_tick_timer = tick_interval
	monitoring = true
	monitorable = true


func _physics_process(delta: float) -> void:
	_time_left -= delta
	_tick_timer -= delta

	if _time_left <= 0.0:
		queue_free()
		return

	if _tick_timer <= 0.0:
		_tick_timer = tick_interval
		_zap()

func _zap() -> void:
	var bodies := get_overlapping_bodies()
	for body in bodies:
		if body is Player:
			var p: Player = body
			if _owner == null or p.player_id != _owner.player_id:
				p.take_hit(_owner.player_id if _owner != null else 0)

func set_field_owner(p: Player) -> void:
	_owner = p
