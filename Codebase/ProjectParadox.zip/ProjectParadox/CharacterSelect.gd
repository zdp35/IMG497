
extends Control

@onready var p1_option: OptionButton = $VBox/P1HBox/P1Option
@onready var p2_option: OptionButton = $VBox/P2HBox/P2Option
@onready var start_button: Button = $VBox/StartButton
@onready var back_button: Button = $VBox/BackButton

func _ready() -> void:
	p1_option.clear()
	p1_option.add_item("Joan of Arc")
	p1_option.add_item("Nikola Tesla")
	p1_option.selected = 0

	p2_option.clear()
	p2_option.add_item("Joan of Arc")
	p2_option.add_item("Nikola Tesla")
	p2_option.selected = 1

	start_button.pressed.connect(_on_start_pressed)
	back_button.pressed.connect(_on_back_pressed)

func _on_start_pressed() -> void:
	var g := get_tree().root.get_node_or_null("Globals")
	if g != null:
		g.p1_character = _index_to_name(p1_option.selected)
		g.p2_character = _index_to_name(p2_option.selected)
	get_tree().change_scene_to_file("res://Main.tscn")

func _on_back_pressed() -> void:
	get_tree().change_scene_to_file("res://Title.tscn")

func _index_to_name(i: int) -> String:
	match i:
		0:
			return "JOAN"
		1:
			return "TESLA"
		_:
			return "JOAN"
