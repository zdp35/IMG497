extends Control

func _ready() -> void:
	var start_button := $VBox/StartButton
	var quit_button := $VBox/QuitButton

	start_button.pressed.connect(_on_start_pressed)
	quit_button.pressed.connect(_on_quit_pressed)

	$VBox/TitleLabel.add_theme_font_size_override("font_size", 28)
	

func _on_start_pressed() -> void:
	get_tree().change_scene_to_file("res://CharacterSelect.tscn")

func _on_quit_pressed() -> void:
	get_tree().quit()
