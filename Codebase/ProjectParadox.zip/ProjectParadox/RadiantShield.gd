extends Area2D
class_name RadiantShield

@export var active_time := 3.0

var _owner: Player = null
var _time_left := 0.0

func _ready() -> void:
    _time_left = active_time
    add_to_group("joan_shield")
    monitoring = true
    monitorable = true

func init_shield(owner: Player, facing_right: bool) -> void:
    _owner = owner
    if not facing_right:
        scale.x = -1.0

func _physics_process(delta: float) -> void:
    _time_left -= delta
    if _time_left <= 0.0:
        queue_free()

func reflect_bullet(bullet: Bullet) -> void:
    bullet.direction.x *= -1.0
    if _owner != null:
        bullet.owner_id = _owner.player_id
