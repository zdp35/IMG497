
extends Node

var p1_character: String = "JOAN"
var p2_character: String = "TESLA"
