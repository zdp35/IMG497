extends Area2D
class_name SwordSlash

@export var duration := 0.18
@export var knockback_force := 500.0

var owner_id: int = 0
var direction: Vector2 = Vector2.RIGHT
var _time_accum := 0.0
var _start_angle := PI / 2.0
var _end_angle := 0.0

func _ready() -> void:
    body_entered.connect(_on_body_entered)

func _physics_process(delta: float) -> void:
    _time_accum += delta
    if _time_accum >= duration:
        queue_free()
        return

    var t: float = clamp(_time_accum / duration, 0.0, 1.0)
    var angle: float = lerp(_start_angle, _end_angle, t)

    # Flip sweep direction based on facing
    if direction.x < 0.0:
        angle = -angle

    rotation = angle

func set_owner_id(id: int) -> void:
    owner_id = id

func set_direction(dir: Vector2) -> void:
    if dir.length() > 0.0:
        direction = dir.normalized()
    else:
        direction = Vector2.RIGHT

func _on_body_entered(body: Node) -> void:
    if body is Player:
        var p: Player = body
        if p.player_id != owner_id:
            # Apply knockback away from the slash center
            var dir := (p.global_position - global_position).normalized()
            p.velocity += dir * knockback_force
            p.take_hit(owner_id)
            queue_free()
